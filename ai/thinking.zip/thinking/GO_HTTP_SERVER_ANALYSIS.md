# Go 服务器的 HTTP API 网关实现 (`ai_agents/server/internal/http_server.go`)

该文件定义了 Go 服务器的所有 HTTP API 端点，并处理请求解析、业务逻辑分派以及响应生成。它使用了 `gin-gonic/gin` web 框架。

#### 1. **定义的 API 端点**

Go 服务器通过 `gin` 框架暴露了以下关键 HTTP 端点：

*   `/`: `GET` - `handlerHealth` (健康检查)
*   `/health`: `GET` - `handlerHealth` (健康检查)
*   `/list`: `GET` - `handlerList` (列出活跃的 worker，即 `TEN App/Engine` 实例)
*   `/start`: `POST` - `handlerStart` (**启动一个新的 Worker/TEN App 实例，并启动一个图**)。这是核心的控制命令。
*   `/stop`: `POST` - `handlerStop` (**停止一个 Worker/TEN App 实例**)。
*   `/ping`: `POST` - `handlerPing` (心跳，更新 Worker 的活跃时间戳)。
*   `/graphs`: `GET` - `handleGraphs` (读取 `property.json` 并返回预定义的图列表)。
*   `/dev-tmp/addons/default-properties`: `GET` - `handleAddonDefaultProperties` (读取 `agents/ten_packages/extension` 目录下所有扩展的 `property.json`，返回默认属性)。这对于前端动态加载扩展配置很有用。
*   `/token/generate`: `POST` - `handlerGenerateToken` (**生成 Agora RTC/RTM token**)。这是 Agora 集成的关键。
*   `/vector/document/preset/list`: `GET` - `handlerVectorDocumentPresetList` (获取预设的向量文档列表)。
*   `/vector/document/update`: `POST` - `handlerVectorDocumentUpdate` (更新 Worker 中的向量文档集合，通过发送 `update_querying_collection` 命令)。
*   `/vector/document/upload`: `POST` - `handlerVectorDocumentUpload` (上传文件并更新 Worker 中的向量文档，通过发送 `file_chunk` 命令)。

#### 2. **请求和响应结构 (`struct` 定义)**

文件顶部定义了各种请求的 Go 结构体，它们通常通过 `json` tag 与 `JSON` 请求体进行绑定：

*   `PingReq`: 包含 `RequestId`, `ChannelName`。
*   `StartReq`: **非常重要！** 包含 `RequestId`, `ChannelName`, `GraphName`, `RemoteStreamId` (`user_uid`), `BotStreamId` (`bot_uid`), `Token` (Agora token), `WorkerHttpServerPort` (用于 Worker 与 Go 服务器回调通信), `Properties` (动态属性注入), `EnvProperties` (环境变量注入), `QuitTimeoutSeconds`。
*   `StopReq`: 包含 `RequestId`, `ChannelName`。
*   `GenerateTokenReq`: 包含 `RequestId`, `ChannelName`, `Uid` (Agora UID)。
*   `VectorDocumentUpdate`: 包含 `RequestId`, `ChannelName`, `Collection`, `FileName`。
*   `VectorDocumentUpload`: 包含 `RequestId`, `ChannelName`, `File` (`multipart.FileHeader`，用于文件上传)。

响应通过 `s.output(c, code, data)` 方法统一格式化为 `JSON`：`{"code": ..., "msg": ..., "data": ...}`。

#### 3. **Worker 交互 (`workers` 全局变量)**

*   `workers` 似乎是一个全局的 `map` 或并发安全的数据结构，用于存储和管理活跃的 `Worker` 实例（键为 `ChannelName`）。
*   **`handlerPing`**: 更新 `Worker` 的 `UpdateTs`，表明 Worker 活跃。
*   **`handlerStart`**:
    *   执行并发控制：检查 `workers.Size()` 是否超过 `s.config.WorkersMax`。
    *   检查 `ChannelName` 是否已存在。
    *   **Gemini 专用限制**: 如果 `GraphName` 包含“gemini”，则限制同名 `GraphName` 的 Worker 数量 (`MAX_GEMINI_WORKER_COUNT`)。这表明对某些特定 LLM 模型的资源管理有额外策略。
    *   **核心逻辑**: 调用 `newWorker()` 创建新的 `Worker` 实例，并调用 `worker.start(&req)` 来启动 Worker。
    *   **属性处理**: 调用 `s.processProperty(&req)` 动态修改 `property.json`。
    *   将新创建的 `Worker` 实例存储到 `workers` 中 (`workers.SetIfNotExist`)。
*   **`handlerStop`**:
    *   从 `workers` 中获取 `Worker` 实例。
    *   调用 `worker.stop()` 来停止 Worker 进程。
*   **`handlerVectorDocumentUpdate` / `handlerVectorDocumentUpload`**:
    *   从 `workers` 中获取 `Worker` 实例。
    *   调用 `worker.update(&WorkerUpdateReq{})` 向 Worker 发送一个更新命令（`update_querying_collection` 或 `file_chunk`）。这再次证实了 Go 服务器作为 Worker 的**控制平面**，能够向其发送内部命令。

#### 4. **Agora 集成 (`rtctokenbuilder`)**

*   `handlerGenerateToken` 函数是 Agora 集成的明确证据。
*   它使用 `rtctokenbuilder.BuildTokenWithRtm` 根据 `AppId`, `AppCertificate`, `ChannelName`, `Uid` 来生成 Agora RTC/RTM token。
*   这确认了 Go 服务器提供了**信令功能**，负责为客户端（例如 ESP32、Web 浏览器）获取加入 Agora RTC 房间所需的身份验证凭据。

#### 5. **图配置与属性注入 (`processProperty`)**

*   `s.processProperty` 函数是理解**图动态配置**的关键：
    *   它读取预定义的 `PropertyJsonFile` (全局变量 `PropertyJsonFile` 可能指向 `ai_agents/server/property.json`)。
    *   **筛选图**: 根据 `StartReq` 中的 `GraphName`，从 `property.json` 的 `predefined_graphs` 列表中筛选出对应的图定义。
    *   **自动启动**: 强制将筛选后的图的 `auto_start` 字段设置为 `true`。
    *   **动态属性注入**: **最重要的一点**。它遍历 `StartReq` 中的 `req.Properties` 和 `startPropMap`，并将这些动态属性**直接注入**到筛选后的图定义 `JSON` 的 `nodes` (扩展) 的 `property` 字段中。这允许客户端在启动图时，动态配置图中的特定扩展（例如，LLM 模型的 `temperature`，ASR 的 `language`）。
    *   **环境变量替换**: 发现 `regexp.MustCompile(`\${env:([^}|]+)}`)` 正则表达式。它会扫描 `property.json` 中的字符串值，并替换 `"${env:ENV_VAR_NAME}"` 形式的占位符。它优先从 `req.EnvProperties` 中查找环境变量值，如果找不到再从系统环境变量中获取。这提供了强大的**运行时环境配置能力**。
    *   **临时文件**: 修改后的 `property.json` 内容会被写入到 `s.config.LogPath` 下的临时 JSON 文件中（例如 `property-channelname-timestamp.json`），以及对应的日志文件 (`app-channelname-timestamp.log`)。这些文件可能作为启动 Worker 进程时的输入。

#### 6. **向量文档管理 (`VectorDocumentUpdate`, `VectorDocumentUpload`)**

*   这两个端点明确指向了**RAG (Retrieval Augmented Generation)** 或知识库管理功能。
*   `handlerVectorDocumentUpload` 允许上传文件，并将其保存到日志路径下，然后向 Worker 发送一个 `file_chunk` 命令。这表明 Worker 内部有处理文件分块和将其转换为向量表示的逻辑。
*   `handlerVectorDocumentUpdate` 允许更新已存在的向量集合，通过发送 `update_querying_collection` 命令。

---

### 遗漏的细节和深化理解

通过对 `http_server.go` 的深入分析，我们发现了几个之前可能遗漏或未充分认识的细节：

1.  **Go 服务器作为核心控制平面**:
    *   它不仅仅是一个简单的 API 网关，而是 **`TEN App/Engine` 实例的生命周期管理器和配置注入器**。它通过 `handlerStart` 负责启动、配置和监控 `TEN App` 实例。
    *   **部署复杂性增加**: Java 迁移后，我们不仅要实现 `TEN App` 核心，还需要考虑是否要保留一个类似的 Go 外部控制平面，或者将这部分逻辑整合到 Java 中。如果 Go 服务器负责启动 JVM 进程，那么这会是 Java 部署链路的一部分。

2.  **动态配置注入机制**:
    *   `StartReq` 的 `Properties` 和 `EnvProperties`，以及 `processProperty` 函数中的逻辑，详细揭示了**外部请求如何动态修改 `TEN App` 内部的 `property.json` 配置**，从而在运行时配置其内部扩展的行为。这是 `ten-framework` 动态性和灵活性的重要体现。
    *   **Java 迁移建议**: Java 解决方案需要一个等效的机制，可以在启动 `Engine` 实例时，通过外部参数动态覆盖或补充其 `property` 配置。这可能涉及到在 Java 中解析 `JSON` 配置，并使用 Java 的反射或配置绑定库来注入值。

3.  **RAG 功能的存在**:
    *   `handlerVectorDocumentUpdate` 和 `handlerVectorDocumentUpload` 揭示了 `ten-framework` 原生支持向量数据库相关的 RAG 功能，能够管理和更新知识库。
    *   **Java 迁移建议**: 这意味着 Java 引擎如果需要支持类似功能，其内部的 `Extension` 或集成点需要能够与向量数据库（例如 ChromaDB、Pinecone）进行交互，并实现文件上传、分块、向量化和查询更新的逻辑。

4.  **Agora 信令层的核心地位**:
    *   `handlerGenerateToken` 的存在表明 Agora 不仅仅是媒体传输层，这个 Go 服务器是负责**信令协商和认证**的关键组件。
    *   **Java 迁移建议**: Java 引擎可能需要直接集成 Agora SDK 来生成 token，或者在 Java 控制平面中重写此信令逻辑。

5.  **Gin 框架**: Go 服务器使用了 `gin` 框架来构建 HTTP API，这是 Go 生态中常用的 web 框架。

这些发现极大地丰富了我们对 `ten-framework` 整体架构的理解，特别是它如何通过一个独立的 Go 服务器来管理 `TEN App/Engine` 实例的生命周期、动态配置以及作为外部 API 网关提供服务。在接下来的鸿沟分析中，这些信息将是至关重要的一部分。