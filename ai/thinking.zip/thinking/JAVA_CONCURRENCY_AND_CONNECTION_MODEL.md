## Java 迁移中的进程、线程、协程与连接处理方案

将 `ten-framework` 这种复杂的并发模型迁移到 Java 需要仔细考虑 Java 的并发原语，特别是 Java 21+ 引入的**虚拟线程 (Virtual Threads/Project Loom)**，它们是 Java 中最接近 Python 协程的概念。

#### 1. **进程模型 (`Process`)**

- **建议**: 在 Java 中，最直接的对应是一个 JVM 实例。为了实现与 `ten-framework` 类似的横向扩展能力，我们可以继续采用**多 JVM 进程**的模型。
- **优势**:
  - **隔离性**: 每个 JVM 进程拥有独立的内存空间，提供强大的故障隔离。一个进程崩溃不会影响其他进程。
  - **部署灵活性**: 可以将不同的 `TEN App/Engine` 部署在不同的 JVM 进程中，甚至不同的物理机器上，并通过网络通信。
  - **资源管理**: 操作系统可以更好地管理和调度独立的进程。
- **管理**: 多个 Java 进程可以通过外部容器（如 Docker、Kubernetes）进行编排和管理，实现自动扩缩容和负载均衡。

#### 2. **线程与协程模型 (`Thread` & `Virtual Thread`)**

这是最关键的部分，如何将 `libuv` 事件循环和 `asyncio` 协程的优点带到 Java：

##### a. **主 Engine 核心循环**

- **`ten-framework` C/C++ 对应**: `Engine` 的 `libuv` 事件循环，严格 FIFO 队列。
- **Java 方案**:
  - **单线程 `ExecutorService`**: 推荐使用一个专用的 **`Executors.newSingleThreadExecutor()`** 来运行 `Engine` 的核心逻辑。
  - **消息队列**: `Engine` 的 `in_msgs` 队列可以映射为 Java 的 **`BlockingQueue<Message>`** (例如 `LinkedBlockingQueue`)。
  - **职责**: 这个单线程 `ExecutorService` 将负责从 `in_msgs` 队列中按顺序取出消息并分派它们（例如，触发 `onCommand`, `onData` 等）。所有对 `Engine` 内部状态的修改都应通过此线程进行，以保证线程安全和消息顺序。
  - **优势**: 严格保证了消息处理的顺序性，避免了复杂的锁机制，同时利用了 Java 线程的成熟调度能力。

##### b. **连接处理（网络 I/O）**

- **`ten-framework` C/C++ 对应**: `libuv` 的非阻塞 I/O 和事件通知。
- **`ten-framework` Python 对应**: `asyncio` 协程处理连接 I/O。
- **Java 方案**:
  - **`Netty` 框架**: 强烈推荐使用 `Netty`。`Netty` 是一个高性能、事件驱动的网络应用框架，其工作原理与 `libuv` 非常相似，基于 NIO `Selector` 实现非阻塞 I/O。
  - **`EventLoopGroup`**: `Netty` 使用 `EventLoopGroup` 来管理 I/O 线程和事件循环。通常，我们会配置一个 `NioEventLoopGroup`。
  - **虚拟线程与 `Netty` 结合**: 这是最前沿且最匹配 `ten-framework` 协程模型的方案：
    - **每个连接一个虚拟线程**: `Netty` 可以配置为在接收到新连接时，为每个 `Channel`（代表一个连接）关联一个**虚拟线程**。当虚拟线程执行阻塞式 I/O 操作时（例如，从网络读取数据），它会自动“卸载”到底层的平台线程，而不会阻塞该平台线程。一旦数据准备就绪，虚拟线程会“重新挂载”并继续执行。
    - **优势**:
      - **高并发**: 可以在一个 JVM 中处理成千上万个并发连接，而不会耗尽平台线程资源。
      - **编程模型简单**: 虚拟线程使得编写异步代码像编写同步代码一样直观，大大简化了复杂的回调链或响应式流。
      - **资源利用率高**: 虚拟线程的内存开销极小，上下文切换成本极低。
  - **消息入队**: 当 `Netty` ChannelHandler 从连接中解析出完整的 `ten-framework` 消息后，应将这些消息提交到 `Engine` 的 `BlockingQueue<Message>` 中。

##### c. **扩展执行 (`Extension Execution`)**

- **`ten-framework` C/C++ 对应**: 每个 `Extension Thread` 拥有独立的 `libuv` 事件循环。
- **`ten-framework` Python 对应**: `asyncio` 协程在 `Extension Thread` 内部运行。
- **Java 方案**:
  - **每个 Extension 一个虚拟线程**: 类似于连接处理，每个 `Extension` 实例（或逻辑上的一组 `Extension`，对应 `Extension Group`）可以被分配一个**虚拟线程**来执行其 `onCommand`, `onData`, `onAudioFrame`, `onVideoFrame` 等回调。
  - **`ExecutorService.newVirtualThreadPerTaskExecutor()`**: Java 21+ 提供了这个工厂方法，非常适合为每个任务（即每个 `Extension` 的处理逻辑）启动一个虚拟线程。
  - **优势**:
    - **隔离性**: 逻辑上隔离了每个扩展的执行，避免了扩展间的相互阻塞。
    - **简单性**: 扩展可以编写“同步”风格的代码，无需手动管理异步回调。
    - **可伸缩性**: 轻松支持大量扩展，因为虚拟线程非常轻量。
  - **阻塞操作处理**:
    - **I/O 阻塞**: 如果扩展需要执行外部 I/O（例如，调用 LLM API），在虚拟线程中进行这些阻塞调用是高效的，因为虚拟线程会“挂起”而不是阻塞其底层平台线程。
    - **CPU 密集型阻塞**: 如果扩展有 CPU 密集型任务（例如，复杂的媒体处理算法），这些任务仍然应该被明确地 offload 到一个**专用的平台线程池** (`Executors.newFixedThreadPool()`)，以避免阻塞虚拟线程的底层载体线程池，从而影响其他虚拟线程的调度。

#### 3. **连接与消息流转的 Java 处理**

- **连接生命周期**:
  - **Java 迁移建议**: `Connection` 对象应设计为 `AutoCloseable`，确保资源（例如 `Netty Channel`）在不再需要时能被正确关闭。
  - `remote_interface.c` 中 `Engine` 关闭时会关闭所有 `Remote`，这需要 Java `Engine` 在关闭时遍历其活跃 `Remote` 列表并调用它们的 `close()` 方法。
- **线程归属 (`Thread Affinity`)**:
  - `migration.c` 中 `ten_sanitizer_thread_check_set_belonging_thread_to_current_thread` 强调了严格的线程归属。
  - **Java 迁移建议**: 在 Java 中，虽然虚拟线程降低了对显式线程归属的担忧，但对于某些共享的可变状态，仍然需要确保它们仅由特定 `ExecutorService` 或虚拟线程修改，或使用 `java.util.concurrent.atomic` 包中的原子类以及 `ReentrantLock` 等进行同步。对于从网络层接收的消息，它们在进入 `Engine` 的核心队列之前，可能需要先由 `Netty` 的 I/O 线程初步处理（例如，解析 `MsgPack` 头部），然后才提交到 `Engine` 的单线程 `ExecutorService`。
- **消息顺序保证**:
  - **Java 迁移建议**: 核心 `Engine` 采用单线程 `ExecutorService` 及其 `BlockingQueue` 是实现严格 FIFO 消息顺序的关键。所有来自 `Netty` 连接和 `Extension` 的消息，都应提交到这个中心队列。
- **分布式消息**:
  - `MsgPack` over TCP 已经被证实用于应用间通信。
  - **Java 迁移建议**: 在 Java 中，我们可以使用 `Netty` 来实现 `MsgPack` 协议的 TCP 服务端和客户端。`MsgPackSerializer` 和 `MsgPackDeserializer` 将负责将 Java 对象转换为 `MsgPack` 二进制数据，并在 `Netty` 的 `ChannelPipeline` 中作为编码器/解码器集成。

### 整体架构设想（Java）

```mermaid
graph TD;
    subgraph Client/External Systems
        A[External Client 1 (e.g., ESP32)]
        B[External Client 2 (e.g., Web App)]
    end

    subgraph Java TEN App (JVM Process)
        C[Netty Server/Client (I/O Threads)] --> D[MsgPack Decoder/Encoder]
        D -- Decoded MsgPack --> E[Engine Core (Single Thread Executor)]
        E -- Dispatches Commands/Data --> F(Extension Virtual Threads Pool)
        F -- Sends Results/New Msgs --> E
        E -- Sends Messages to Remote --> D
        D -- Encoded MsgPack --> C
        C -- External Network --> G[Other Java TEN App / External Service]

        subgraph Engine Core (Single Thread Executor)
            E1[BlockingQueue<Message>]
            E2[Message Dispatcher & Graph Scheduler]
            E1 --> E2
        end

        subgraph Extension Virtual Threads Pool
            F1[Extension 1 (Virtual Thread)]
            F2[Extension 2 (Virtual Thread)]
            F3[... (Many more Extensions)]
            F1 -- Inter-Extension Comm. --> E2 (via Message Queue)
        end
    end

    A -- HTTP/JSON RPC --> G (API Gateway Implied by ESP32 Client)
    G -- MsgPack over TCP --> C
    B -- WebSocket/MsgPack over TCP --> C
```

**关键点：**

- **分层设计**: 清晰地分离网络 I/O (`Netty`)、核心业务逻辑 (`Engine Core`) 和可插拔功能 (`Extension Virtual Threads`)。
- **虚拟线程的广泛应用**: 大量利用虚拟线程来处理连接和扩展执行，以实现高并发和简化编程模型。
- **单线程核心**: `Engine Core` 保持单线程以保证消息处理顺序，并作为所有消息的中央分派器。
- **消息队列**: 使用 `BlockingQueue` 在各个并发组件之间安全地传递消息。
- **`MsgPack` 协议实现**: 严格实现 `ten-framework` 的两阶段 `MsgPack EXT` 协议。

这是一个相当复杂的议题，但 Java 的新特性（特别是虚拟线程）为我们提供了非常强大的工具来优雅地解决它，同时保留 `ten-framework` 原有设计的并发优势。

#### `Netty` 在 Java `ten-framework` 迁移中的“自身通信”职责再确认

是的，经过再次仔细探查和确认，我的观点依然是：**`Netty` 在我们的 Java `ten-framework` 迁移方案中，将承担核心的“自身通信”职责。这里“自身通信”特指我们的 Java 引擎（`TEN App`）与“外部世界”的互动，以及不同 `TEN App` 实例之间的协同。**

这种设计是基于 `ten-framework` 原始 C/C++ 架构中，`Engine` 通过 `Remote` 和 `Connection` 抽象与外部进行交互的模式，以及 Python 扩展中 `asyncio` 对网络 I/O 的抽象。`Netty` 在 Java 中提供了对这种模式的高性能、高灵活度的对等实现。

让我们再次通过更具体的例子和场景来确认这一点。

---

##### 1. 与其他 `TEN App/Engine` 实例之间的通信：构建分布式图 (`MsgPack over TCP`)

**场景回顾**: `ten-framework` 的核心概念是“图”（Graph），图中的节点可以是本地的 `Extension`，也可以是分布在不同 `TEN App/Engine` 实例上的远程 `Extension`。当消息需要在这些远程 `TEN App` 之间流转时，就需要跨进程/跨机器通信。我们之前在 `MsgPack` 分析中发现，`MsgPack over TCP` 是一个明确的内部通信协议。

**`Netty` 在此处的角色**:

*   **作为服务器**: 我们的 Java `TEN App` 需要能够被其他 `TEN App` 连接。它会启动一个 `Netty` TCP 服务器：
    *   **监听器**: 负责监听一个预定义的端口（例如 `8007`，如测试配置所示）。
    *   **连接管理**: 自动处理 `TCP` 连接的接受、建立、关闭。
    *   **协议编解码**: `Netty ChannelPipeline` 中会插入我们自定义的 `MsgPackDecoder` 和 `MsgPackEncoder`。
        *   `MsgPackDecoder`：负责从传入的 `TCP` 字节流中，解析出完整的 `MsgPack EXT` 格式的 `ten-framework` Java `Message` 对象（例如 `Command`, `Data`）。
        *   `MsgPackEncoder`：负责将 `Engine Core` 产生的 Java `Message` 对象，序列化为 `MsgPack EXT` 格式的字节流，以便通过 `TCP` 发送出去。
    *   **消息转发**: 解析后的 Java `Message` 对象会被提交到本 `TEN App` 的 `Engine Core` 的 `BlockingQueue<Message>` 中，进入核心处理流程。

*   **作为客户端**: 我们的 Java `TEN App` (例如 `App A`) 需要主动连接到 `App B`。它会启动一个 `Netty` TCP 客户端：
    *   **连接发起**: 根据配置的 URI（例如 `msgpack://remote_ip:8007/`）主动发起 `TCP` 连接。
    *   **连接维护**: 负责连接的重连、心跳等机制。
    *   **协议编解码**: 同样在 `ChannelPipeline` 中集成 `MsgPackEncoder` 和 `MsgPackDecoder`，处理 Java `Message` 对象与 `MsgPack` 字节流之间的双向转换。
    *   **消息发送**: 将 `Engine Core` 要发送的 Java `Message` 对象通过 `Netty` 连接发送给目标 `TEN App`。

**为什么是 `Netty`？**

*   **高性能**: `Netty` 专为高性能网络 I/O 设计，与 `libuv` 类似，能够高效处理大量并发连接和数据吞吐。
*   **非阻塞**: `Netty` 基于 NIO，所有 I/O 操作都是非阻塞的，与 `ten-framework` 的事件驱动模型一致。
*   **协议栈**: 其 `ChannelPipeline` 机制允许灵活地构建协议栈，方便插入 `MsgPack` 编解码器。
*   **成熟稳定**: 作为广泛使用的框架，提供稳定可靠的 `TCP` 通信能力。

---

##### 2. 与 `ten-framework` 客户端之间的通信：提供外部服务接口

这指的是为 `ESP32` 设备、Web 浏览器前端、移动应用等外部客户端提供统一的接入点，让他们能够与 `ten-framework` Java 引擎进行交互。

**a. `HTTP/JSON RPC` (例如 `ESP32` 客户端的控制命令)**

**场景回顾**: `ESP32-client` 的 `ai_agent.c` 显示，它通过 `HTTP POST` 请求发送控制命令（如 `TENAI_AGENT_START`, `TENAI_AGENT_STOP`），请求体是 `JSON` 格式。这暗示 `TEN App` 对外提供了一个 `HTTP API` 网关层。

**`Netty` 在此处的角色**:

*   **作为 `HTTP` 服务器**: 我们的 Java `TEN App` 会启动一个 `Netty` `HTTP` 服务器：
    *   **请求解析**: `Netty` 的 `HttpServerCodec` 和 `HttpObjectAggregator` 等 `Handler` 会自动处理 `HTTP` 请求的解析（方法、URI、头部、完整 `body`）。
    *   **`JSON` 提取与解析**: 自定义的 `ChannelHandler` 会从 `HTTP` 请求的 `body` 中提取 `JSON` 数据。
        *   使用 `Jackson` 或 `Gson` 等 Java `JSON` 库，将 `JSON` 反序列化为特定的 Java **请求对象**（例如 `StartGraphRequest` Java 类）。
        *   将这些请求对象转换为 `ten-framework` 内部的 Java `Command` 对象，并提交到 `Engine Core` 的 `BlockingQueue` 中。
    *   **响应生成**: `Engine Core` 处理完命令并返回 `CommandResult` 后，该 `ChannelHandler` 会将 `CommandResult` 序列化为 `JSON` 格式，并通过 `Netty` 作为 `HTTP` 响应（例如 `200 OK` 或 `4xx Error`）发送回 `ESP32` 客户端。

**b. `WebSocket` (例如 `Web` 浏览器前端的实时媒体和数据)**

**场景回顾**: 实时对话应用中，浏览器或移动端通常通过 `WebSocket` 传输实时音频/视频流（二进制数据）和控制消息（文本/二进制）。

**`Netty` 在此处的角色**:

*   **作为 `WebSocket` 服务器**: 我们的 Java `TEN App` 会启动一个 `Netty` `WebSocket` 服务器：
    *   **`HTTP` 升级到 `WebSocket`**: `Netty` 会处理标准的 `HTTP` 握手请求，并将其升级到 `WebSocket` 连接。
    *   **`WebSocket` 帧处理**: `Netty` 的 `WebSocketServerProtocolHandler` 会处理 `WebSocket` 协议的细节（例如，`ping/pong`、帧的拆分与重组）。
    *   **消息编解码**: 自定义的 `ChannelHandler` 会处理 `WebSocket` 帧的内容：
        *   **接收二进制帧**: 如果帧包含 `MsgPack` 编码的 `AudioFrame` 或 `VideoFrame`，`Netty` 会通过 `MsgPackDecoder` 将其解析为 Java `AudioFrame` / `VideoFrame` 对象，并提交到 `Engine Core`。
        *   **接收文本帧**: 如果帧包含 `JSON` 或 `MsgPack` 编码的命令或数据（例如，文本消息），`Netty` 会使用相应的解码器将其解析为 Java `Message` 对象，并提交到 `Engine Core`。
        *   **发送帧**: 当 `Engine Core` 生成 `AudioFrame`、`VideoFrame` 或文本响应时，`Netty` 会使用我们自定义的 `MsgPackEncoder`（或 `JSON` 编码器）将其序列化为二进制/文本数据，并作为 `WebSocket` 帧发送回客户端。

---

### 总结确认

是的，**`Netty` 是我们 Java `TEN App` 的“网络边界守护者”和“协议转换器”**。它不会深入到 `Extension` 内部去干预 `Extension` 调用第三方 SDK 的网络行为，因为那是 `Extension` 的“内部逻辑”和“外部服务集成”职责。

`Netty` 的职责是：

*   **对内**: 与 `Engine Core` 的 `BlockingQueue<Message>` 进行交互，接收和发送标准的 Java `Message` 对象。
*   **对外**: 面向外部网络（无论是其他 `TEN App` 还是客户端），处理各种网络协议的复杂性，将外部协议数据转换为内部的 `Message` 对象，并将内部 `Message` 对象转换为外部协议数据。

这种设计确保了：

1.  **清晰的职责分离**: 核心 `Engine` 专注于业务逻辑和图调度，无需关心网络协议细节。
2.  **协议可插拔性**: 可以在 `Netty` 层轻松添加或修改对新网络协议的支持，而不会影响 `Engine` 核心。
3.  **高性能和可伸缩性**: `Netty` 提供了处理高并发连接和数据流所需的基础设施。
4.  **Java 惯用语**: 充分利用了 Java 生态系统中成熟的网络框架。

我相信这份再次确认和详细的例子解释能够更清晰地阐明 `Netty` 在此方案中的核心作用。我将把这份更新加入到 `ai/thinking/JAVA_CONCURRENCY_AND_CONNECTION_MODEL.md` 文档中。
