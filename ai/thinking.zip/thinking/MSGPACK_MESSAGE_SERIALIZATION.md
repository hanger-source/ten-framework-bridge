# `MsgPack` 消息序列化与反序列化实现 (`packages/core_protocols/msgpack/msg/msg.c`)

该文件是 `ten-framework` 内部消息对象与 `MsgPack` 序列化格式之间转换的**核心实现**。它展示了如何遍历消息字段、处理不同消息类型以及封装为 `MsgPack EXT` 格式。

#### 1. **通用字段处理 (`ten_msg_field_serialize`, `ten_msg_field_deserialize`)**

*   **抽象化处理**: 这两个函数是通用的回调，用于处理 `ten-framework` 消息中的单个字段。它们被 `ten_msg_loop_all_fields` 函数调用，该函数会遍历消息的所有注册字段。
*   **`ten_value_t` 抽象**: 它们操作的是 `ten_value_t` 类型的字段值。这表明 `ten-framework` 内部有一个统一的 `Value` 抽象层，可以表示不同类型的数据（整数、字符串、二进制、JSON 等）。
*   **`ten_msgpack_value_serialize` / `ten_msgpack_value_deserialize`**: 核心转换发生在这些函数中。它们负责将 `ten_value_t` 对象序列化为相应的 `MsgPack` 原语（例如，`MsgPack` 整数、字符串、二进制等），或反之。这提供了一种**反射式或元数据驱动**的序列化/反序列化机制。

#### 2. **单个 `ten-framework` 消息的序列化 (`ten_msgpack_serialize_msg`)**

*   **消息类型序列化**: `ten_msgpack_msg_type_serialize(ten_msg_get_raw_msg(self), pck);` (Line 81)。这是关键的第一步。在序列化消息的字段之前，它会先序列化消息的**类型** (`TEN_MSG_TYPE`)。这使得反序列化器能够知道它正在处理哪种 `ten-framework` 消息（例如，`Cmd`, `Data`, `AudioFrame`, `VideoFrame`）。
*   **遍历字段并序列化**: `ten_msg_loop_all_fields(self, ten_msg_field_serialize, pck, err);` (Line 83)。它使用 `ten_msg_loop_all_fields` 函数遍历消息的所有内部字段，并为每个字段调用 `ten_msg_field_serialize`，从而将所有字段序列化到 `MsgPack` 打包器中。

#### 3. **单个 `ten-framework` 消息的反序列化 (`ten_msgpack_deserialize_msg`)**

*   **读取消息类型**: `TEN_MSG_TYPE msg_type = ten_msgpack_deserialize_msg_type(unpacker, unpacked);` (Line 91)。这是反序列化的第一步，它从 `MsgPack` 流中读取消息的类型。
*   **创建消息对象**: `ten_shared_ptr_t *new_msg = ten_msg_create_from_msg_type(msg_type);` (Line 93)。基于读取到的消息类型，它动态地创建一个新的、空的 `ten-framework` 消息对象（例如，`_Cmd` 的实例，`_Data` 的实例等）。
*   **遍历字段并反序列化**: `ten_msg_loop_all_fields(new_msg, ten_msg_field_deserialize, info, NULL);` (Line 99)。它使用 `ten_msg_loop_all_fields` 遍历新创建消息的所有字段，并为每个字段调用 `ten_msg_field_deserialize`，从而将 `MsgPack` 数据填充到消息对象的相应字段中。

#### 4. **批量消息序列化 (`ten_msgpack_serialize_msgs`)**

*   **`MsgPack EXT` 封装策略**: 文件中的长篇注释 (Lines 111-145) 解释了 `ten-framework` 为什么选择使用 `MsgPack EXT` 机制来封装其内部结构（`struct`）。
    *   `MsgPack EXT` 允许传输带有 `size` 和 `type` 的二进制数据。
    *   这解决了如何让接收端知道何时接收到完整 `struct` 数据以及该 `struct` 是何种类型的问题。
    *   **两阶段序列化**:
        1.  **内部序列化**: 遍历消息列表 (`msgs`)，对于每个 `ten_shared_ptr_t *msg`，首先通过一个临时的 `msgpack_packer pck_for_each_msg` 将其自身序列化成一个独立的 `MsgPack` 字节流 (`sbuf_for_each_msg.data`)。这个内部序列化由 `ten_msgpack_serialize_msg` 完成。
        2.  **外部封装**: 然后，将这个内部序列化后的 `MsgPack` 字节流作为 `body`，使用 `MsgPack EXT` 类型 (`TEN_MSGPACK_EXT_TYPE_MSG`) 封装，并通过主 `msgpack_packer pck` (`&sbuf`) 打包。`msgpack_pack_ext_with_body` (Line 171) 是关键函数。
*   **性能考虑**: 注释提到了 `sbuf.data` 的内存管理是“hack”，因为它期望由 `MsgPack` 库分配的内存能被 `TEN` 的 `TEN_FREE` 机制正确释放，这可能导致兼容性问题或性能开销（如果需要 `memcpy` 到 `TEN_MALLOC` 的内存）。

#### 5. **批量消息反序列化 (`ten_msgpack_deserialize_msgs`)**

*   **两阶段反序列化**:
    1.  **外部解包 (`MsgPack EXT` 层)**: `ten_msgpack_parser_feed_data` (Line 207) 将输入的 `ten_buf_t` 喂给通用的 `MsgPack` 解析器 (`parser`，它处理 `EXT` 对象)。
    2.  **内部解包 (`ten-framework` 消息层)**: 在 `while(true)` 循环中，`ten_msgpack_parser_parse_data(parser)` 被反复调用。我们知道这个函数会从 `EXT` 负载中提取数据，并进一步调用 `ten_msgpack_deserialize_msg` 来创建 `ten-framework` 消息对象。
*   **流式处理**: `while` 循环确保即使在一个批次的输入缓冲区中包含多个消息，也能逐个解析出来。

### 补充见解和深化理解

*   **基于元数据的序列化**: `ten_msg_loop_all_fields` 与 `ten_value_t` 和 `ten_msgpack_value_serialize/deserialize` 的结合，表明 `ten-framework` 内部有一个强大的元数据系统，能够描述消息的结构和字段类型，从而实现通用的序列化和反序列化逻辑，而无需为每种消息类型编写大量重复代码。这是一种**数据驱动的序列化**。
*   **严格的协议结构**: 两阶段的 `MsgPack EXT` 封装 (`TEN_MSGPACK_EXT_TYPE_MSG`) 强制了严格的线上传输格式。任何与 `ten-framework` 交互的外部组件（包括 Java 迁移后的服务）都必须遵守这种确切的二进制协议结构。
*   **消息创建的类型驱动**: 反序列化过程中，先读取消息类型，然后根据类型动态创建具体的消息对象，这也是典型的多态反序列化模式。

### 对 Java 迁移的影响

`msg.c` 文件提供了实现 Java `MsgPack` 序列化/反序列化所需的所有精确细节。

1.  **Java 中 `MsgPack` 消息的精确映射**:
    *   **Java 迁移建议**: 我们需要为 `Cmd`, `Data`, `AudioFrame`, `VideoFrame` 等 `Message` 子类创建 Java POJO 或 `record` 类型，并确保其字段与 `ten-framework` C 结构中的字段及其 `MsgPack` 编码类型精确匹配。
    *   **核心挑战**：Java 实现的关键将是复制 `ten_msg_loop_all_fields` 的功能以及 `ten_value_t` 的行为。这可能需要使用 Java 的**反射 (Reflection API)** 来遍历 Java 消息对象的字段，并使用 `MsgPack-Java` 库的低级 `MessagePacker` 和 `MessageUnpacker` API 来手动写入/读取 `MsgPack` 原语。或者，可以为每种消息类型生成代码，但这会增加复杂性。一个更实用的方法是设计一个通用的 `MessageSerializer` 和 `MessageDeserializer`，它们通过内部的**Schema 描述**（例如，定义每个消息类型包含哪些字段、字段的 `MsgPack` 类型是什么）来驱动序列化/反序列化过程。

2.  **Java 中的两阶段序列化/反序列化**:
    *   **Java 迁移建议**: Java 实现必须严格遵循 `MsgPack EXT` 封装的两阶段模式。
        1.  **序列化**: 将 Java 消息对象序列化为 `MsgPack` Map/Array，然后将此内部 `MsgPack` 数据打包为 `MsgPack EXT` 对象（使用 `TEN_MSGPACK_EXT_TYPE_MSG` 类型码）。
        2.  **反序列化**: 首先解包顶层的 `MsgPack EXT` 对象并验证其类型码。然后从 `EXT` 负载中获取内部 `MsgPack` 数据，并进一步反序列化为正确的 Java `Message` 子类实例（例如，`Command`, `Data`）。

3.  **Java 中的批量处理**:
    *   **Java 迁移建议**: 支持批量序列化/反序列化以提高效率。Java `MessagePackSerializer` 可以具有 `byte[] serializeAll(List<Message> messages)` 和 `List<Message> deserializeAll(byte[] serializedData)`。这意味着对单个消息（反）序列化的循环。

4.  **错误处理**:
    *   `ten_msgpack_serialize_msg` 中的 `ten_error_t` 参数意味着错误报告。
    *   **Java 迁移建议**: Java 序列化/反序列化方法应在失败时抛出自定义异常（例如，`MessagePackSerializationException`、`MessagePackDeserializationException`）。

这份文件是 `ten-framework` 二进制通信协议的“操作手册”。理解这些细节对于在 Java 中构建一个功能对等、高性能和兼容的实时对话引擎至关重要。